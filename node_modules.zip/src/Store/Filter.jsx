import React from 'react'

function Filter() {
  return (
    <div className='sticky top-[20vh] md:hidden  left-0 min-h-[100vh] w-[250px] border-2 border-black'>
       <h1>Filter</h1>
    </div>
  )
}

export default Filter